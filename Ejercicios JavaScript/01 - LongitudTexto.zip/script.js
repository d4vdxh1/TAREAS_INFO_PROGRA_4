// script.js

// Agregar un evento de clic al botón
document.getElementById("botonCalcular").onclick = function() {
    const texto = document.getElementById("inputTexto").value;
    const longitud = texto.length;

    // Mostrar la longitud en el elemento con id "resultado"
    document.getElementById("resultado").innerText = `La longitud del texto es: ${longitud} caracteres.`;
};
