function registrarAsistencia() {
  var nombre = document.getElementById("nombre").value;
  var apellido = document.getElementById("apellido").value;
  var email = document.getElementById("email").value;
  var carrera = document.getElementById("carrera").value;
  var asistira = document.getElementById("asistira").checked ? "Sí" : "No";
  
  var mensaje = "Registro exitoso:\n\n" +
                "Nombre: " + nombre + "\n" +
                "Apellido: " + apellido + "\n" +
                "Correo electrónico: " + email + "\n" +
                "Carrera: " + carrera + "\n" +
                "Asistirá a la charla: " + asistira;
  
  alert(mensaje);
}
